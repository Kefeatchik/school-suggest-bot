"""Точка входа: школьная анонимная «предложка»."""
from __future__ import annotations

import asyncio
import logging
import os
import sys

# Безопасный вывод в консоль: не падать из-за кодировки кириллицы в cmd.
for _stream in (sys.stdout, sys.stderr):
    if hasattr(_stream, "reconfigure"):
        _stream.reconfigure(errors="replace")

from aiogram import Bot, Dispatcher

import context
from config import Config
from database import Database
from handlers import admin, user

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)


async def _start_health_server() -> None:
    """Мини-HTTP-сервер для health-check хостингов (Koyeb / Render / Fly и т.п.).

    Запускается только если задана переменная окружения PORT (так делают PaaS).
    """
    from aiohttp import web

    async def health(_request):
        return web.Response(text="ok")

    app = web.Application()
    app.router.add_get("/", health)
    app.router.add_get("/health", health)

    runner = web.AppRunner(app)
    await runner.setup()
    port = int(os.getenv("PORT", "8080"))
    site = web.TCPSite(runner, "0.0.0.0", port)
    await site.start()
    logging.info("Health-сервер слушает порт %s", port)
    await asyncio.Event().wait()  # держим сервер живым


async def main() -> None:
    cfg = Config.from_env()
    db = Database()
    await db.connect()
    context.init(db, cfg)

    # Необязательный прокси для Telegram (если хостинг/сеть без прямого доступа).
    session = None
    if cfg.proxy_url:
        from aiohttp import ClientSession
        from aiohttp_socks import ProxyConnector

        session = ClientSession(connector=ProxyConnector.from_url(cfg.proxy_url))

    bot = Bot(token=cfg.bot_token, session=session)
    dp = Dispatcher()
    # admin-роутер первым, чтобы команды (/stats, /ban, /mute …) не перехватывались
    # catch-all обработчиком пользовательского роутера.
    dp.include_router(admin.router)
    dp.include_router(user.router)

    me = await bot.get_me()
    logging.info("Бот запущен: @%s (id=%s)", me.username, me.id)

    if not cfg.admin_ids:
        logging.warning("ADMIN_IDS не задан — модерация не будет работать.")
    if not cfg.channel_id:
        logging.warning("CHANNEL_ID не задан — одобренные посты не будут публиковаться.")
    if not cfg.moderation_chat_id:
        logging.warning("MODERATION_CHAT_ID не задан — посты не будут попадать на модерацию.")

    if os.getenv("PORT"):
        asyncio.create_task(_start_health_server())

    try:
        await bot.delete_webhook(drop_pending_updates=True)
        await dp.start_polling(bot)
    finally:
        await db.close()
        await bot.session.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logging.info("Остановлено.")
